import GUI.ApplicationFrame;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationFrame app = new ApplicationFrame();
		
	}

}
