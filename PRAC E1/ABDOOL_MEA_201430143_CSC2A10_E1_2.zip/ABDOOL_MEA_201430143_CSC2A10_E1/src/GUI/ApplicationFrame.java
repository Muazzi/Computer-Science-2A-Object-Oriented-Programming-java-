package GUI;
import acse.csc2a.Cipher;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;

public class ApplicationFrame extends JFrame {
		private JTextArea plain,encrypted; 
	private JButton   encrypt , decrypt;
	private CipherPanel Cpanel;
	public ApplicationFrame()
	{   
		Dimension size = new Dimension(300,300);
		setSize(size);
		setPreferredSize(size);
		setTitle("DDUS");
	  Cpanel=  new CipherPanel(); 
	  plain = new JTextArea(5,10);
	  encrypted = new JTextArea(1,1);
	  plain.setLineWrap(true);
	  JScrollPane scroller = new JScrollPane(plain);
	  scroller.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
	  scroller.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
	  encrypt = new JButton("Click me to  encrypt");
	  decrypt =  new JButton("Click me to  decrypt");
	  encrypt.addActionListener(new EncryptListner());
	  decrypt.addActionListener(new DecryptListener());
	  Cpanel.add(decrypt);
	  Cpanel.add(encrypt);
	  Cpanel.add(encrypted,BoxLayout.Y_AXIS);
	  Cpanel.add(scroller);
	  
	  add(Cpanel);
	  this.pack();
	   setVisible(true);
	  
	}
	    class EncryptListner implements ActionListener
	    {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				plain.setText("");
				String in = plain.getText(); 
				encrypted.append(Cipher.transform(in)+"\n");
			}
	    	
	    }
	    class DecryptListener  implements ActionListener
	    {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				plain.setText("");
				String in =encrypted.getText(); 
				plain.append(Cipher.transform(in)+"\n");
			}
	    	
	    }

}
