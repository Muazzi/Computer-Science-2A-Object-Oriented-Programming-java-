package GUI;



import javax.swing.BoxLayout;
import javax.swing.JPanel;

public class CipherPanel extends JPanel {
	
	public void init()
	{
		requestFocus();
	}

	public CipherPanel()
	{
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		setFocusable(true);	
	}

}
